import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';

void main() => runApp(const YaseenGamesApp());

class YaseenGamesApp extends StatelessWidget {
  const YaseenGamesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Yaseen Games',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF111111),
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepOrange,
          brightness: Brightness.dark,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class Game {
  final String title;
  final String emoji;
  final List<Color> colors;
  const Game(this.title, this.emoji, this.colors);
}

const games = [
  Game('Rocket Demo', '🚀', [Color(0xFF281B55), Color(0xFFB51F62)]),
  Game('Lucky 777', '🎰', [Color(0xFF162B5B), Color(0xFF6D1FC2)]),
  Game('Piggy Bank', '🐷', [Color(0xFF7A320E), Color(0xFFFFA51F)]),
  Game('Fortune Gems', '💎', [Color(0xFF0B5B35), Color(0xFFE4A52B)]),
  Game('Crazy 777', '7️⃣', [Color(0xFF5B189A), Color(0xFFFFB31A)]),
  Game('Money Spin', '💵', [Color(0xFF177D36), Color(0xFF4DBB55)]),
  Game('Wild Showdown', '🤠', [Color(0xFFB86D08), Color(0xFFE4C13B)]),
  Game('Anubis', '🐺', [Color(0xFF241F2D), Color(0xFF7B4024)]),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int nav = 0;
  int category = 0;
  int coins = 5000;

  final categories = const [
    ('🔥', 'Hot'),
    ('🎰', 'Slots'),
    ('🧩', 'Mini Games'),
    ('🎣', 'Fishing'),
    ('🃏', 'Cards'),
    ('⚽', 'Sports'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(
          index: nav,
          children: [
            _home(),
            _simplePage('Promo', '🎁', 'Daily virtual-coin rewards'),
            _simplePage('Wallet', '🪙', 'Virtual coins only — no cash withdrawal'),
            _simplePage('VIP', '👑', 'VIP levels and demo rewards'),
            _simplePage('Profile', '👤', 'Login, settings and account'),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF090909),
        selectedIndex: nav,
        onDestinationSelected: (i) => setState(() => nav = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.card_giftcard_outlined), selectedIcon: Icon(Icons.card_giftcard), label: 'Promo'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
          NavigationDestination(icon: Icon(Icons.workspace_premium_outlined), selectedIcon: Icon(Icons.workspace_premium), label: 'VIP'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _home() {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(child: _header()),
        SliverToBoxAdapter(child: _banner()),
        SliverToBoxAdapter(child: _brandRow()),
        SliverToBoxAdapter(child: _actionRow()),
        SliverToBoxAdapter(child: _categoryRow()),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          sliver: SliverGrid(
            delegate: SliverChildBuilderDelegate(
              (_, i) => _gameCard(games[i % games.length]),
              childCount: games.length,
            ),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: .86,
            ),
          ),
        ),
      ],
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
      child: Row(
        children: [
          const Text('YASEEN', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: -1)),
          const Text('GAMES', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Colors.deepOrange)),
          const Spacer(),
          IconButton(onPressed: () {}, icon: const Icon(Icons.search, size: 29)),
        ],
      ),
    );
  }

  Widget _banner() {
    return Container(
      height: 150,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: const LinearGradient(
          colors: [Color(0xFF461400), Color(0xFFFF6A00), Color(0xFF24100A)],
        ),
        boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 12)],
      ),
      child: Stack(
        children: [
          const Positioned(
            left: 20, top: 22,
            child: Text('WELCOME BONUS', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          ),
          const Positioned(
            left: 20, top: 58,
            child: Text('Virtual coins • Daily missions', style: TextStyle(fontSize: 14)),
          ),
          Positioned(
            right: 18, bottom: 15,
            child: Text('🎁  🪙  🎮', style: TextStyle(fontSize: 48)),
          ),
        ],
      ),
    );
  }

  Widget _brandRow() {
    return SizedBox(
      height: 92,
      child: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        scrollDirection: Axis.horizontal,
        children: ['777', 'BET', '88', 'DX', 'VIP', 'PLAY'].map((x) =>
          Container(
            width: 82, margin: const EdgeInsets.only(right: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: LinearGradient(colors: [Colors.orange.shade900, Colors.black]),
              border: Border.all(color: Colors.orange.withOpacity(.55)),
            ),
            child: Center(child: Text(x, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19))),
          )
        ).toList(),
      ),
    );
  }

  Widget _actionRow() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: Row(
        children: [
          Expanded(child: _action('🪙', 'Coins', '$coins')),
          const SizedBox(width: 8),
          Expanded(child: _action('🎁', 'Bonus', 'Claim')),
          const SizedBox(width: 8),
          Expanded(child: _action('👥', 'Invite', 'Friends')),
        ],
      ),
    );
  }

  Widget _action(String icon, String title, String sub) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 11),
      decoration: BoxDecoration(color: const Color(0xFF1B1B1B), borderRadius: BorderRadius.circular(14)),
      child: Column(children: [
        Text(icon, style: const TextStyle(fontSize: 22)),
        const SizedBox(height: 2),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(sub, style: const TextStyle(fontSize: 11, color: Colors.white60)),
      ]),
    );
  }

  Widget _categoryRow() {
    return SizedBox(
      height: 84,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        itemBuilder: (_, i) {
          final selected = category == i;
          return GestureDetector(
            onTap: () => setState(() => category = i),
            child: Container(
              width: 92, margin: const EdgeInsets.only(right: 10),
              decoration: BoxDecoration(
                color: selected ? const Color(0xFF2A2A2A) : const Color(0xFF181818),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: selected ? Colors.deepOrange : Colors.white10),
              ),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(categories[i].$1, style: const TextStyle(fontSize: 22)),
                const SizedBox(height: 3),
                Text(categories[i].$2, style: const TextStyle(fontSize: 12)),
              ]),
            ),
          );
        },
      ),
    );
  }

  Widget _gameCard(Game game) {
    return GestureDetector(
      onTap: () => _openGame(game),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: game.colors,
          ),
          boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 8, offset: Offset(0, 5))],
        ),
        child: Stack(
          children: [
            Center(child: Text(game.emoji, style: const TextStyle(fontSize: 58))),
            Positioned(
              top: 9, right: 9,
              child: Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(color: Colors.black38, borderRadius: BorderRadius.circular(20)),
                child: const Icon(Icons.star_border, size: 18),
              ),
            ),
            Positioned(
              left: 12, right: 12, bottom: 12,
              child: Text(game.title, textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      ),
    );
  }

  void _openGame(Game game) {
    if (game.title == 'Rocket Demo') {
      Navigator.push(context, MaterialPageRoute(builder: (_) => RocketDemoPage(
        startingCoins: coins,
        onCoinsChanged: (value) => setState(() => coins = value),
      )));
      return;
    }
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF171717),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(game.emoji, style: const TextStyle(fontSize: 60)),
          Text(game.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Demo mode: play using virtual coins only.', textAlign: TextAlign.center),
          const SizedBox(height: 18),
          FilledButton(
            onPressed: () {
              setState(() => coins = (coins + 100).clamp(0, 999999));
              Navigator.pop(context);
            },
            child: const Text('PLAY DEMO +100 COINS'),
          ),
        ]),
      ),
    );
  }

  Widget _simplePage(String title, String emoji, String subtitle) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(emoji, style: const TextStyle(fontSize: 70)),
          const SizedBox(height: 12),
          Text(title, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60)),
        ]),
      ),
    );
  }
}


class RocketDemoPage extends StatefulWidget {
  final int startingCoins;
  final ValueChanged<int> onCoinsChanged;
  const RocketDemoPage({
    super.key,
    required this.startingCoins,
    required this.onCoinsChanged,
  });

  @override
  State<RocketDemoPage> createState() => _RocketDemoPageState();
}

class _RocketDemoPageState extends State<RocketDemoPage> {
  Timer? _timer;
  double multiplier = 1.00;
  double? roundCrash;
  bool running = false;
  bool cashedOut = false;
  int coins = 0;
  int bet = 100;
  final Random _random = Random();

  @override
  void initState() {
    super.initState();
    coins = widget.startingCoins;
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void startRound() {
    if (running || coins < bet) return;
    setState(() {
      coins -= bet;
      multiplier = 1.00;
      roundCrash = 1.4 + _random.nextDouble() * 4.8;
      running = true;
      cashedOut = false;
    });
    widget.onCoinsChanged(coins);
    _timer = Timer.periodic(const Duration(milliseconds: 80), (timer) {
      if (!mounted) return;
      setState(() {
        multiplier *= 1.012;
        if (multiplier >= (roundCrash ?? 2.0)) {
          multiplier = roundCrash!;
          running = false;
          timer.cancel();
        }
      });
      if (!running && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Round ended at ${multiplier.toStringAsFixed(2)}x')),
        );
      }
    });
  }

  void cashOut() {
    if (!running || cashedOut) return;
    final win = (bet * multiplier).floor();
    setState(() {
      coins += win;
      cashedOut = true;
      running = false;
    });
    _timer?.cancel();
    widget.onCoinsChanged(coins);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Demo cash-out: +$win virtual coins')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final progress = ((multiplier - 1) / 5).clamp(0.0, 1.0);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rocket Demo'),
        backgroundColor: Colors.transparent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF1B1B1B),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  const Text('🪙 Virtual Coins', style: TextStyle(fontWeight: FontWeight.bold)),
                  const Spacer(),
                  Text('$coins', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color(0xFF20124D), Color(0xFF090A13)],
                  ),
                  border: Border.all(color: Colors.white12),
                ),
                child: Stack(
                  children: [
                    const Positioned(top: 20, left: 20, child: Text('DEMO ROUND', style: TextStyle(color: Colors.white54))),
                    Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '${multiplier.toStringAsFixed(2)}x',
                            style: const TextStyle(fontSize: 64, fontWeight: FontWeight.w900),
                          ),
                          const SizedBox(height: 20),
                          Text(running ? '🚀 Flying...' : (roundCrash == null ? 'Ready' : 'Round ended'),
                              style: const TextStyle(fontSize: 18, color: Colors.white70)),
                          const SizedBox(height: 24),
                          SizedBox(
                            width: 220,
                            child: LinearProgressIndicator(value: running ? progress : 0),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: running ? null : () => setState(() => bet = max(10, bet - 50)),
                    child: const Text('BET -'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 13),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1B1B1B),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text('$bet coins', style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: running ? null : () => setState(() => bet = min(1000, bet + 50)),
                    child: const Text('BET +'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: FilledButton(
                    onPressed: running ? null : startRound,
                    child: const Text('START ROUND'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.tonal(
                    onPressed: running ? cashOut : null,
                    child: const Text('CASH OUT'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            const Text(
              'Demo only • virtual coins have no cash value.',
              style: TextStyle(fontSize: 12, color: Colors.white54),
            ),
          ],
        ),
      ),
    );
  }
}
