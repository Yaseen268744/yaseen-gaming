# Yaseen Games — Android Flutter Prototype

This is a starter Android UI prototype based on the supplied reference screenshot.

## Included
- Dark/orange mobile gaming UI
- Home screen
- Banner
- Categories
- Game cards
- Virtual coin balance
- Promo/Wallet/VIP/Profile tabs
- Rocket/Aviator-style demo round using virtual coins only
- Bet controls and demo cash-out
- Demo round multiplier animation

## Run
1. Install Flutter and Android Studio.
2. Create a Flutter project or replace the `lib/main.dart` and `pubspec.yaml` with these files.
3. Run:
   flutter pub get
   flutter run

This prototype does not implement real-money betting, deposits, withdrawals, or cash gambling.
